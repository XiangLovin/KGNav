package chen.kgnav;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KgnavApplicationTests {

    @Test
    void contextLoads() {
    }

}
