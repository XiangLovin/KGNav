package chen.kgnav;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KgnavApplication {

    public static void main(String[] args) {
        SpringApplication.run(KgnavApplication.class, args);
    }

}
